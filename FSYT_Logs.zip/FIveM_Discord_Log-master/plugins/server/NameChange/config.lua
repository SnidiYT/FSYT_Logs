NameChangeConfig = {}

NameChangeConfig.AcePermission = '[server_name].staff' 